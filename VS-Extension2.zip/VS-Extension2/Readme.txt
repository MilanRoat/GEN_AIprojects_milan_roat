this file contains original files created by - Milan Roat
for a vs-code extension (by command name - 'Get Suggestion')

API Key used - GROQ API (the API key in extension.ts is empty for now . use your own key to get results)
Model used - llama3-8b-8192

the main logic code for a this copilot to help/give suggestion of selected text is in extension.ts file.


to use this extension - follow the steps
save and compile all files
press f5
now the window opened will have the extension loaded . 

- open any code file in any language
- select some code lines which you want to get results
- use 'Get Suggesion' command from extensions window . (i.e. press ctrl+shift+P)

- the results will be added to the code file.

the added screenshots below are while using this copilot for a selected code .