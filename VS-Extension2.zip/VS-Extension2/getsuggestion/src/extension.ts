import * as vscode from 'vscode';
import Groq from 'groq-sdk';


const groq = new Groq({ apiKey: 'empty space for API key' });



async function getGroqChatCompletion(prompt: string): Promise<{completion: string, explanation: string}> {
    
    const response = await groq.chat.completions.create({
        messages: [
            { role: "user", content: prompt }
        ],
        model: "llama3-8b-8192"
    });

    const completion = response.choices[0]?.message?.content || "No completion found.";
    const explanation = "//code explaination."; 

    return { completion, explanation };
}


async function generateExplanation(completion: string): Promise<string> {
    
    return "This code initializes an API client and fetches code completions.";
}

export function activate(context: vscode.ExtensionContext) {
    let disposable = vscode.commands.registerCommand('getsuggestion.helloWorld', async () => {
        const editor = vscode.window.activeTextEditor;
        if (!editor) {
            vscode.window.showInformationMessage('Open a file first to get suggestions');
            return;
        }

        const codeSnippet = editor.document.getText(editor.selection);
        try {
            const { completion, explanation } = await getGroqChatCompletion(codeSnippet);

            
            const formattedResponse = `${completion}\n\n// Explanation: ${explanation}`;

           
            editor.edit(editBuilder => {
                editBuilder.replace(editor.selection, formattedResponse);
            });
        } catch (error: unknown) {
            const errMsg = (error instanceof Error) ? error.message : 'Unknown error';
            vscode.window.showErrorMessage(`Failed to fetch suggestion: ${errMsg}`);
        }
    });

    context.subscriptions.push(disposable);
}

export function deactivate() {}



